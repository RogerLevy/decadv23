<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="dungeon" tilewidth="16" tileheight="16" tilecount="171" columns="19">
 <image source="../assets/dungeon.png" width="304" height="144"/>
</tileset>
